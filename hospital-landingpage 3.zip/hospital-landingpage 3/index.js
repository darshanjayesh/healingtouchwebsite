const btnRequestAppointment = document.querySelector(
  ".button-request-appoinment"
);
btnRequestAppointment.addEventListener("click", () => {
  window.open("https://api.whatsapp.com/send?phone=7558096800&text=Hai");
});

const searchPopUp = document.querySelector(".popup-search");
const btnSearchTrigger = document.querySelector(".action-search-triger");
const btnCloseSearch = document.querySelector(".popup-search-button-close");
const toogleSearchMobile = document.querySelector(".navbar-action-search");
const mobileMenu = document.querySelector(".menu-mobile");
const hamburgerTrigger = document.querySelector(".navbar-action-menu");

// * Search functionallity
btnSearchTrigger.addEventListener("click", () => {
  searchPopUp.classList.add("active");
});
btnCloseSearch.addEventListener("click", () => {
  searchPopUp.classList.remove("active");
});

// * Search functionallity on mobile
toogleSearchMobile.addEventListener("click", () => {
  if (toogleSearchMobile.classList.contains("active")) {
    toogleSearchMobile.classList.remove("active");
    searchPopUp.classList.remove("active");
  } else {
    toogleSearchMobile.classList.add("active");
    searchPopUp.classList.add("active");
  }
});

// * Hamburger menu (mobile device)
hamburgerTrigger.addEventListener("click", () => {
  if (hamburgerTrigger.classList.contains("active")) {
    hamburgerTrigger.classList.remove("active");
    mobileMenu.classList.remove("active");
  } else {
    hamburgerTrigger.classList.add("active");
    mobileMenu.classList.add("active");
  }
});

// * location search dekstop
const locationTrigerDekstop = document.querySelector(
  ".search-location-dekstop"
);
const locationTrigerDekstopPopUp = document.getElementById("locDeksPopup");
const locationDekstopTrigerClose = document.querySelector(".locDeksPopupClose");
locationTrigerDekstop.addEventListener("click", () => {
  if (locationTrigerDekstop.classList.contains("active")) {
    locationTrigerDekstop.classList.remove("active");
    locationTrigerDekstopPopUp.style.display = "none";
  } else {
    locationTrigerDekstop.classList.add("active");
    locationTrigerDekstopPopUp.style.display = "grid";
  }
});
locationDekstopTrigerClose.addEventListener("click", () => {
  locationTrigerDekstop.classList.remove("active");
  locationTrigerDekstopPopUp.style.display = "none";
});

// * location search dekstop
const locationTrigerMobile = document.querySelector(".search-location-mobile");
const locationTrigerMobilePopup = document.getElementById("locMobPopup");
const locationMobileTrigerClose = document.querySelector(".locMobPopupClose");
locationTrigerMobile.addEventListener("click", () => {
  if (locationTrigerMobile.classList.contains("active")) {
    locationTrigerMobile.classList.remove("active");
    locationTrigerMobilePopup.style.display = "none";
  } else {
    locationTrigerMobile.classList.add("active");
    locationTrigerMobilePopup.style.display = "grid";
  }
});
locationMobileTrigerClose.addEventListener("click", () => {
  locationTrigerMobile.classList.remove("active");
  locationTrigerMobilePopup.style.display = "none";
});

// * Button handle for get current location
const btnCurrentLocations = document.querySelectorAll(".btn-current-location");
// biome-ignore lint/complexity/noForEach: <explanation>
btnCurrentLocations.forEach((btnCurrentLocation) => {
  btnCurrentLocation.addEventListener("click", () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        console.log(position)
      });
    } else {
      console.log("geolocation IS NOT available")
    }
  });
});
